/* 
 * File:   Space.h
 * Author: Ezequiel Hernandez
 * Created on April 28, 2021, 10:35 PM
 */
#include<vector>
#ifndef SPACE_H
#define SPACE_H
class Space{
private:
  int position;
  bool empty,slide;
  char spaceColor;
public:
    Space();
    Space(int, char);
    bool empty();// returns true if space is empty
    void empty(bool);// returns true if space is empty
    bool isSlide(); //returns slide
    void makeSlide(bool); //makes Space a slide space
    int getPos();//returns board position 
    char getClr();// returns the color of the space
};
#endif /* SPACE_H */
Space::Space(){}
Space::Space(int n, char clr){
    position=n;
    spaceColor= clr;
    empty = false;
    slide= false;
}
bool Space::empty(){
    return empty;
}
void Space::empty(bool t){
    empty= t;
}
bool Space::isSlide(){
    return slide;
}
void Space::makeSlide(bool b){
    slide= b;
}
int Space::getPos(){
    return position;
}
char Space::getClr(){
    return spaceColor;
}
