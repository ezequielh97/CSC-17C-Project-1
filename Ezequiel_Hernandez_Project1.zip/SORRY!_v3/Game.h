/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Game.h
 * Author: ezequ
 *
 * Created on April 30, 2021, 1:49 PM
 */

#include <queue>

#include"Player.h"
#include"GameBoard.h"
#include"Deck.h"

#ifndef GAME_H
#define GAME_H
class Game{
private:
    std::queue<Player> turns;// game will loop thought queue t keep track of the turns
    Deck deck;
    GameBoard board;
    int numP;///number of players
    bool win;
    
public:
    Game(int);
    void start();//initialize the players
    bool end();//checks if any players have their home full at the end of their turn
    
    
};
Game::Game(int players){
    numP= players;
    for(int i=1;i<=players;i++){
        turns.push(Player(i));
    }
    
}
void Game::start(){
    cout<<deck.getCard().first;
}

#endif /* GAME_H */