

#include<map>
#include<list>
#include <set>
#include <iterator>
#include <iostream>
#include "Space.h"
#include<string>
#include<algorithm>
using namespace std;
#ifndef GAMEBOARD_H
#define GAMEBOARD_H



class GameBoard{
private:
int players;
std::set<int> taken;
set<string> past59; //names that pass the the upper left corner are put in 
                               // past 59 and taken out when they move into their safe zone
std::set<int> safe;
list<Space> safeZones;
std::list<Space> track;

std::set<string> p1start;
std::set<string> p1home;
std::set<string> p2start;
std::set<string> p2home;
std::set<string> p3start;
std::set<string> p3home;
std::set<string> p4start;
std::set<string> p4home;
void toStart(string);// takes iterator and makes position of the pawn -1; adds that pawn's name to start
void inStart(set<string> &);//outputs all keys currently in start 
void inHome(set<string> &);//outputs all keys currently in home
 string getName(int);// returns the pawns name    
std::string board[16][16]={
         {"Y ", "$ ", "Y ", "Y ", "Y ", "¤ ", "Y ", "Y ", "Y ", "Y ", "Y ", "Y ", "Y ", "Y ", "Y", "G"},
         {"B", "  ", "║ ", "≡", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " $"},
         {"B", "  ", "║ ", " ", " ", " ", " ", " ", "  ", "Ø ", "═ ", "═ " , "═ ", "═ " , "═ ", "G"},
         {"B", "  ", "║ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "G"},
         {"B", "  ", "║ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "≡", "G"},
         {"B", "  ", "║ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "G"},
         {"B", "  ", "Ø ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "G"},
         {"B", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "G"},
         {"B", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "G"},
         {"B", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "   ", "  ", "  ", "Ø", " ", "G"},
         {"¤", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "   ", "  ", "  ", "║ ", " ", "G"},
         {"B", " ≡", " ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "   ", "  ", "   ", " ║ ", " ", "G"},
         {"B", "  ", "  ", "  ", "  ", "  ", "  ", "   ", "  ", "  ", "  ", "  ", "  ", " ║", " ", "G"},
         {"B", " ═", " ═", " ═", " ═", " ═", "Ø", "  ", "  ", "  ", " ", " ", " ", "  ║", "  "," G"},
         {"$ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " ≡", "  ", "║", " ", " G"},
         {"B ", "R ", "R ", "R ", "R ", "R ", "R ", "R ", "R ", "R ", "R ", "R ", "R ", "R ", " $", " R"},
    };// blank board game
        //each player has a safety zone that leads to home
      //Ø is home, pawns that land on $ slide forward 4 spaces to ¤
public:
   friend class Space;
   typedef map<string, int> pawnMap;// stores the position and the color/key of each pawn the players pawns
    pawnMap pawns; 
  ~GameBoard();
   GameBoard();
   GameBoard(int);
    void printBoard();
    void refresh();// iterates through track, if position is occupied by pawns, sets Space.isEmpty to false
    void setPawnPos(string, int);
    bool isTaken(int); // checks to see if input is in the set of taken
    bool fullHouse();//return true when aplayer has moved all his pawns home
};
#endif /* GAMEBOARD_H */

GameBoard::GameBoard(int numPlayers){
players=numPlayers;
std::string r= "R";
std::string y= "Y";
std::string g= "G";
std::string b= "B";
    for(int i=0;i<=14;i++){// fills Yellow track with empty spaces
      track.push_back(Space(y,i));}
    for(int i=15;i<=29;i++){// fills Green track with empty spaces
      track.push_back(Space(g,i));}
    for(int i=30;i<=44;i++){// fills Red track with empty spaces
      track.push_back(Space(r,i));}
    for(int i=45;i<=59;i++){// fills Blue track with empty spaces
      track.push_back(Space(b,i));}
std::list<Space> p1Safezone;
std::list<Space> p2Safezone;
std::list<Space> p3Safezone;
std::list<Space> p4Safezone;
    for(int i=100;i<=104;i++){// fills  Yellow Safe zone with empty spaces
      p1Safezone.push_back(Space(y,i));}
    for(int i=105;i<=109;i++){// fills Green Safe zone with empty spaces
       p2Safezone.push_back(Space(g,i));}
    for(int i=110;i<=114;i++){// fills Red Safe zone  with empty spaces
       p3Safezone.push_back(Space(r,i));}
    for(int i=115;i<=119;i++){// fills Blue Safe zone with empty spaces
       p4Safezone.push_back(Space(b,i));}

    merge(p3Safezone.begin(), p3Safezone.end(),
          p4Safezone.begin(), p4Safezone.end(),
          inserter(safeZones,safeZones.begin()));
  merge(p1Safezone.begin(), p1Safezone.end(),
          p2Safezone.begin(), p2Safezone.end(),
         inserter(safeZones,safeZones.begin()));

for(int i=49;i<= 52;++i){   
    switch(players){
        case 2:  
            pawns.insert(make_pair(y+(char)i,-1));//-1 position indicates pawns are at start
            p1start.insert(y+(char)i);
            pawns.insert(make_pair(g+(char)i,-1));//keys are set to Y1,Y2,Y3....
            p2start.insert(g+(char)i);
            break;
        case 3:  
            pawns.insert(make_pair(y+(char)i,-1));//-1 position indicates pawns are at start
            p1start.insert(y+(char)i);
            pawns.insert(make_pair(g+(char)i,-1));//keys are set to Y1,Y2,Y3....
            p2start.insert(g+(char)i);
            pawns.insert(make_pair(r+(char)i,-1));
            p3start.insert(r+(char)i);
            break;
        case 4:  
            pawns.insert(make_pair(y+(char)i,-1));//-1 position indicates pawns are at start
            p1start.insert(y+(char)i);
            pawns.insert(make_pair(g+(char)i,-1));//keys are set to Y1,Y2,Y3....
            p2start.insert(g+(char)i);
            pawns.insert(make_pair(r+(char)i,-1));
            p3start.insert(r+(char)i);
            pawns.insert(make_pair(b+(char)i,-1));
            p4start.insert(b+(char)i);
            break; 
    }
 }
} 
GameBoard::~GameBoard(){  }
void GameBoard::printBoard(){
    for(int i=0;i<16;i++){
        for(int j=0;j<16;j++){
                std::cout<< board[i][j];
        }
        std::cout<<std::endl;
    }  
    cout<<endl;
    switch(players){
        //case 1:
        case 2:
            cout<<"Yellow  "; inStart(p1start);
            cout<<"Yellow  "; inHome(p1home);
            cout<<"Green   "; inStart(p2start);
            cout<<"Green   "; inHome(p2home);
            break;
         case 3:
            cout<<"Yellow  "; inStart(p1start);
            cout<<"Yellow  "; inHome(p1home);
            cout<<"Green   "; inStart(p2start);
            cout<<"Green   "; inHome(p2home);
            cout<<"Red     "; inStart(p3start);
            cout<<"Red     "; inHome(p3home);
            break;
         case 4:
            cout<<"Yellow  "; inStart(p1start);
            cout<<"Yellow  "; inHome(p1home);
            cout<<"Green   "; inStart(p2start);
            cout<<"Green   "; inHome(p2home);
            cout<<"Red     "; inStart(p3start);
            cout<<"Red     "; inHome(p3home);
            cout<<"Blue    "; inStart(p4start);
            cout<<"Blue    "; inHome(p4home);
            break;
    }   
}
string GameBoard::getName(int pos){
  pawnMap::iterator pwns;
 
    for(pwns=pawns.begin();pwns!=pawns.end();++pwns){
        if(pwns->second==pos){
            return pwns->first;
        } 
    }return "Error";}
/*  $ and ¤ are meant to be slide spaces but I did not have enough time to
 * program in the feature. It took me a while to get this refresh function to work because the
 * matrix indexes are inverted for the red and blue spaces  */
void GameBoard::refresh(){        
    std::list<Space>::iterator space;
    pawnMap::iterator p;
  
    int pos;// holds the currently occupied spaces
    for(p=pawns.begin();p!=pawns.end();++p){  // inserts occupied positions into a set
        if(p->second>=0 && p->second<=59){
            taken.insert(p->second);
        }else if(p->second>=100 && p->second<=119){
            safe.insert(p->second); }
    }
    for(space=track.begin();space!=track.end();++space){// if a position is full that Space is set to be not empty
        pos=space->getPos();
        if (taken.find(pos) != taken.end() ){
            space->notEmpty();
        }
    }
    for(space=track.begin();space!=track.end();++space){//changes the string in Board if corresponding space is full 
        pos= space->getPos();
        if(space->isEmpty()!=true){
            
            if(pos>=0&&pos<=14){        //y 
                board [0][pos]= getName(pos);
            }
            else if(pos>=15&&pos<=29){
                board[pos-15][15]=getName(pos);//green side
            }
            else if(pos>=30&&pos<=44){
                                                //r side
                board[15][45-pos]= getName(pos);
            }
            else if(pos>=45&&pos<=59){// b side
             board[60-pos][0]= getName(pos);
            }
    }else if(space->isEmpty()==true){     // output for empty spaces
        if(pos>=0 && pos<=14){        //Y side
            if(pos==1||pos==9){
                board[0][pos]="$ ";
            }else if(pos==4||pos==13){
                board[0][pos]="¤ ";
            }else  board[0][pos]= "Y ";                    
            }
        else if(pos>= 15 && pos<=29){          //green side                  
          if(pos==16){board[1][15]=" $";}                          
            else if(pos==24){board[9][15]="  $";}                    
                else if(pos==19){board[4][15]=" ¤";}
                    else if(pos==28){board[13][15]= "¤";}
                    else  board [pos-15][15]=" G";  
            }
        else if(pos >=30&&pos<=44){               //Red side
               if(pos==31){board [15][14]=" $";}  
               else if(pos==39){board [15][6]=" $";}          //y to x
                 else if(pos==34){board [15][11]=" ¤";}
                      else if (pos==43){board[15][2]=" ¤";}
                      else board[15][45-pos]= " R";
            }
       else if(pos >=45&&pos<=59){       //blue side
               if(pos==46){board [0][13]="$ ";}  
               else if(pos==54){board [6][0]="$ ";}            // y to x
                 else if(pos==49){board [11][0]="¤";}
                      else if (pos==58){board[2][0]="¤ ";}
                      else board[60-pos][0]= "B ";
            } 
        }
          taken.clear(); 
    }
    // same process but now for safeZones
    for(space=safeZones.begin();space!=safeZones.end();++space){  // if a position is full that Space is set to be not empty
        pos=space->getPos();
        if (safe.find(pos)!= safe.end()){
            space->notEmpty(); } }
    for(space=safeZones.begin();space!=safeZones.end();++space){  // if a position is full that Space is set to be not empty
        pos=space->getPos();
        if (space->isEmpty()!= true){
        
            if(pos>=100&&pos<=104){        //y 
                board [pos-99][2]= getName(pos);
            } 
            else if(pos>=105&&pos<=109){
                board[2][119-pos]=getName(pos);//green side
            }
            else if(pos>=110&&pos<=114){       //r side
                board[124-pos][13]= getName(pos);          //going higher than 120 wont display
            }
            else if(pos>=115&&pos<=119){// b side           
             board[13][pos-114]= getName(pos);
            }
      
    }else if(space->isEmpty()== true){
        
         if(pos>=100&&pos<=104){        //y 
                board [pos-99][2]= "║";
            }
            else if(pos>=105&&pos<=109){
                board[2][pos-95]=" ═";//green side
               
            }
            else if(pos>=110&&pos<=114){
                                                //r side
                board[pos-100][13]= "║";
            }
            else if(pos>=115&&pos<=119){// b side
             board[13][pos-114]= " ═";
            }
        }
    }
 }  
bool GameBoard::fullHouse() {
    if(p1home.size()==4){
       printf("Yellow wins!!!!");
       printf("Ending Program.....");
       return true;
    }  else if(p2home.size()==4){
       printf("Green wins!!!!");
       printf("Ending Program.....");
       return true;
    }else if(p3home.size()==4){
       printf("Red wins!!!!");
       printf("Ending Program.....");
       return true;
    }else if(p4home.size()==4){
       printf("Blue wins!!!!");
       printf("Ending Program.....");
       return true;
    }else 
     return !true;
}
void GameBoard::toStart(string key){
    char s =key.at(0);
    switch(s){
            case 'Y':
                taken.erase(pawns.at(key));
                p1start.insert(key);
                pawns[key]= -1;        
                break;
            case 'G':
                taken.erase(pawns.at(key));
                p2start.insert(key);
                pawns[key]= -1;
                break;
            case 'R':
                taken.erase(pawns.at(key));
                p3start.insert(key);
                pawns[key]= -1;
                break;
             case 'B':
                 taken.erase(pawns.at(key));
                 p4start.insert(key);
                pawns[key]= -1;
                 break;
        }; 
}
void GameBoard::inStart(set<string> &start){
    set<string>::iterator pos;
    cout <<" pawns in start: "; 
    for(pos=start.begin();pos!=start.end();++pos){
        cout<< *pos <<" "; 
    }
    cout<<endl;
}
void GameBoard::inHome(set<string> &home){
    set<string>::iterator pos;
    cout <<" pawn's in home: "; 
    for(pos=home.begin();pos!=home.end();++pos){
        cout<< *pos <<" "; 
    }
    cout<< endl;
}
void GameBoard::setPawnPos(string pawn, int move){
      char s = pawn.at(0);
      int pos;
      pos= move+pawns[pawn];    // new position is old position + move
    if(pawns[pawn]== -1){
        switch(s){
            case 'Y':
                p1start.erase(pawn);
                pawns[pawn]= 3+move;
                break;
            case 'G':
                p2start.erase(pawn);
                pawns[pawn]= 18+move;
                break;
            case 'R':
                p3start.erase(pawn);
                pawns[pawn]= 33+move;
                break;
             case 'B':
                 p4start.erase(pawn);
                 pawns[pawn]= 48+move;
                 break;
        };
    }else if(pawns[pawn]>=0&&pawns[pawn]<99){
        switch(s){
            case 'Y':
                if(pos>104){
                    p1home.insert(pawn);
                }else if(pos>100){
                    pawns[pawn]=pos;
                }
                else if(pos>=60){
                  past59.insert(pawn);
                    pos=60-pos;
                    }
               else if(pos>2 && past59.find(pawn)!=past59.end() )
               { pawns[pawn]=100;
               past59.erase(pawn);
                        }else
                break;
            case 'G':
               if(pos>109){
                    p2home.insert(pawn);
                }else if(pos>105){
                    pawns[pawn]=pos;
                }
                else if(pos>=60){
                  past59.insert(pawn);
                    pos=60-pos;
                    }
                else if(pos>19 && past59.find(pawn)!=past59.end()){
                      pawns[pawn]=105;
                       past59.erase(pawn);
                        }else
                break;
            case 'R':
               if(pos>114){
                    p3home.insert(pawn);
                }else if(pos>110){
                    pawns[pawn]=pos;
                }
                else if(pos>=60){
                  past59.insert(pawn);
                    pos=60-pos;
                    }
                else if(pos>32 && past59.find(pawn)!=past59.end()){
                      pawns[pawn]=110;
                       past59.erase(pawn);
                        }else
                break;
             case 'B':
               if(pos>119){
                    p4home.insert(pawn);
                }else if(pos>115){
                    pawns[pawn]=pos;
                }
                else if(pos>=60){
                  past59.insert(pawn);
                    pos=60-pos;
                    }
                else if(pos>49 && past59.find(pawn)!=past59.end()){
                      pawns[pawn]=115;
                       past59.erase(pawn);
                        }else
                 break;
        };
    if(isTaken(pos)==true){
        toStart(getName(pos)); }
    pawns[pawn]=pos;
    }
    
    //pawns[pawn]=pos;
}
bool GameBoard::isTaken(int pos){
    set<int>::iterator i;
    i=find(taken.begin(),taken.end(),pos);
    if(i!=taken.end()){   return true;    
    }else return false;
}