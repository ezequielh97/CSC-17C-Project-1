/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Game.h
 * Author: ezequ
 *
 * Created on May 5, 2021, 4:26 AM
 */
#include <queue>
#include"GameBoard.h"
#include "Deck.h"
#include<string>

#ifndef GAME_H
#define GAME_H
class Game{
private:
    Deck *deck;
    std::queue<std::string> turns;  //a queue of  "Yellow", "Red", "Green" and "Blue" to represent players and their turns
    GameBoard *board;
    int numP;     //number of players
    bool win;
    
public:
   ~Game();
    Game(int);
    void start();    // start looping through the queue of players colors to 
    void move(int, char);    // takes user choice input, changes the position of the players pawns
    void split(int,char); // ask player how to split their move; calls move twice
    void sorry();     // send players pawn to their start area
    void playerTurns();
    void pawnSwitch();    //switches player pawn positions
    string inputValidation(char);
};
Game::Game(int players){
    numP= players;
    deck= new Deck();
    board =new GameBoard(players);
    switch(players){
        case 4:
        turns.push("Blue");
        case 3:
        turns.push("Red");
        case 2:
            turns.push("Yellow");
            turns.push("Green");
            break;  
    };
}
Game::~Game(){}
void Game::start(){
    do{
 board->refresh();
 board->printBoard();
 playerTurns();
 win=board->fullHouse();       
    }while (win==false);
}
//Input: name of pawn being moved, value that pawned will be moved by
//Output:: moves the pawn
void Game::move(int move, char plrClr){
    string pawn;
    pawn= inputValidation(plrClr);
    board->setPawnPos(pawn, move);
    }
void Game::playerTurns(){
    pair<int,char> card;
    do{
       cout<< turns.front()<< " player's turn. "<<endl;
       printf("Press Enter to draw a card\n");
       cin.get();
       card =deck->draw();
       if(card.second=='M'){
       move(card.first,turns.front().at(0));
       }else if(card.second== 'S'){
           sorry();
       }else if(card.second== 'W'){
           pawnSwitch();
       }else if(card.second=='P'){
           split(card.first, turns.front().at(0));
       }
       turns.pop();
       board->refresh();
 board->printBoard();
    }
    while(turns.size()!=0);
 switch(numP){
        case 4:
        turns.push("Blue");
        case 3:
        turns.push("Red");
        case 2:
            turns.push("Yellow");
            turns.push("Green");
            break;  
    };
}
// player pawns chooses a pawn to target. targeted pawn is sent back to start by setPawnPos
void Game::sorry(){
    string pawn;
    string target;
    int temp;
    cout<< "Input a pawn to move out of your start area."<< endl;
    cin>> pawn;
    cout<< "Which pawn's place will yours take?"<< endl;
    cin>> target;
    temp=board->pawns[target];
    board->setPawnPos(pawn,temp);
}
void Game::split(int move, char plyrClr){
    int move2;
    int move1;
    string pawn1;
    string pawn2;
    cout<< " Input the first pawn you wish to move"<< endl;
    cin >> pawn1;
    cout << " How many space will it move? "<< endl;
    cin >> move1;
    cout<< " Which other pawn would you like to move?"<< endl;
    cin>> pawn2;
    board->setPawnPos(pawn1, move1);
    move2= move-move1;
    board->setPawnPos(pawn2, move2); 
}
void Game::pawnSwitch(){
    string pawn;
    string target;
    int temp;
    cout<< " Input a your pawn you wish to be switch."<< endl;
    cin >> pawn;
    cout << " Which pawn's place will your pawn switch with? "<< endl;
    cin >> target;
    temp= board->pawns[target];
    board->pawns[target]=board->pawns[pawn];
    board->pawns[pawn]=temp;
}
string Game::inputValidation(char clr){
    string pawn;
    cout << " Input the pawn you wish to move.(ex: Y2, R4, G1)" << endl;
    cin >> pawn;
    while(pawn.at(0)!=clr){
        cout<< " Thats not one of your pawns, try again."<< endl;
        cin>> pawn;
    }
    return pawn;
}
#endif /* GAME_H */