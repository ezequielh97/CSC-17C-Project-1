/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Space.h
 * Author: ezequ
 *
 * Created on May 5, 2021, 4:26 AM
 */
#ifndef SPACE_H
#define SPACE_H
class Space{
private:
  int position;
  bool empty;
  std::string spaceColor;
public:
    friend bool operator < (const Space& lhs, const Space& rhs) { return lhs.position < rhs.position;}  
    Space();
    ~Space();
    Space(std::string,int);
    bool isEmpty();// returns true if space is empty
    void makeEmpty();// 
    void notEmpty();
    int getPos();//returns board position 
    void setPos(int);//
    std::string getClr();// returns the color of the space
};
#endif /* SPACE_H */
Space::Space(){}
Space::~Space(){
}
Space::Space(std::string clr, int n){
    position=n;
    spaceColor= clr;
    empty = true;
}
bool Space::isEmpty(){
    return empty;
}
void Space::makeEmpty(){
    empty= true;
}
int Space::getPos(){
    return position;
}
void Space::setPos(int pos){
    position=pos;
}

std::string Space::getClr(){
    return spaceColor;
}
 void Space::notEmpty(){
     empty= false;
     
          }
 