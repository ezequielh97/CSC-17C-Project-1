/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Deck.h
 * Author: ezequ
 *
 * Created on May 1, 2021, 11:18 PM
 */
#include<string>
#include<algorithm>
#include<cstdlib>
#include <stack>
#ifndef DECK_H
#define DECK_H
using namespace std;
class Deck{
private:
std::stack<std::pair<int, char>> cards;
void fillDeck(){
    int val;
    char effect;
    std::vector<std::pair<int, char>> temp;
    for(int i=0;i<=12;i++){
        for(int j=0;j<=3;j++){
            if(i!=6&&i!=9){
                val=i;
            if(i>=1 && i<= 5){
                effect='M';
            }else{
                switch(i) {
      case 0:
          effect='S';
         break;              
      case 7:
         effect='P';
         break;
      case 8 :
          effect='M';
          break;
      case 10 :
         effect='B';
         break;
      case 11 :
         effect='s';
         break;
      case 12 :
         effect='M';
         break;
      }
            } temp.push_back(std::make_pair(val, effect)); 
        }
    }
    }
    std::random_shuffle(temp.begin(),temp.end());
    for(int i=0;i<44;i++){
        cards.push(temp.back());
        temp.pop_back();
    }
}
public:
    Deck();
    ~Deck();
    std::pair<int,char> getDeck();
    std::pair<int,char> draw();// returns a pair, telling Game whether the player wants to move,split their move, or switch pawns. 
    
#endif /* DECK_H */
};
Deck::Deck(){
    fillDeck();
}

std::pair<int,char> Deck::draw(){
    std::pair<int,char> temp;
    std:pair<int, char> move;
    int choice;
    temp = cards.top();
    cards.pop();
           switch(temp.second) {
      case 'S':
          std::cout<<" You drew a SORRY! card!!! You may: "<<endl;
          std::cout<<"1.)Move a pawn from your start area to take the place of another player's pawn, which must return to its own start area."<< endl;
          std::cout<<"2.)Move one of your pawns forward four spaces."<<endl;
          cin >> choice;
          if(choice==1){
              return temp;
          }else{
              temp.first=4;
              temp.second='M';
              return temp;
          }
         break;              
      case 'P':
           std::cout<<" You drew 7.You may: "<< endl;
           std::cout<<"1.)Move one of your pawns forward seven spaces"<< endl;
           std::cout<<"2.)Split the forward move between two of your pawns."<<endl;
           cin >> choice;
          if(choice==2){
              return temp;
          }else{
              temp.first=7;
              temp.second='P';
              return temp;
          }
         break;
      case 'M':
        std::cout<< " You drew a move card. Move one of your pawns forward "<< temp.first<< " spaces."<< endl;
        return temp;
          break;
      case 'B' :
           std::cout<<" You drew 10. You may:"<< endl;
           std::cout<<"1.)Move one of your pawns forward ten spaces"<<endl;
           std::cout<<"2.)Move one of your pawns backward one space."<< endl;
           cin >> choice;
          if(choice==1){
              temp.first=10;
              temp.second='M';
              return temp;
          }else{
              temp.first=-1;
              temp.second='M';
              return temp;
          }
         break;
      case 's' :
          std::cout<<" You drew 11. You may"<< endl;
          std::cout<< "1.)Move one of your pawns forward 11 spaces"<< endl;
          std::cout<< "2.)Switch any one of your pawns with an opponent's."<< endl;
         cin >> choice;
          if(choice==1){
              temp.first=11;
              temp.second= 'M';
              return temp;
          }else{
              temp.first=0;
              temp.second='w';
              return temp;
          }
         break;
      }   
     return temp;      
}