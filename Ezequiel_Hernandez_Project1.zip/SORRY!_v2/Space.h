/* 
 * File:   Space.h
 * Author: Ezequiel Hernandez
 * Created on April 28, 2021, 10:35 PM
 */

#ifndef SPACE_H
#define SPACE_H
class Space{
private:
  int position;
  bool empty;
  char spaceColor;
public:
    Space();
    Space(int, char);
    bool isEmpty();// returns true if space is empty
    void makeEmpty();// 
    int getPos();//returns board position 
    char getClr();// returns the color of the space
};
#endif /* SPACE_H */
Space::Space(){
    position=0;
    empty=true;  
}
Space::Space(int n, char clr){
    position=n;
    spaceColor= clr;
    empty = true;
}
bool Space::isEmpty(){
    return empty;
}
void Space::makeEmpty(){
    empty= true;
}
int Space::getPos(){
    return position;
}
char Space::getClr(){
    return spaceColor;
}
