/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: ezequ
 *
 * Created on April 27, 2021, 10:13 PM
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <map>
#include"Player.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    Player p1(1);
    Player p2(2);
    p1.setPawnPos("R2", 4);
   // p.setPawnPos("R3", 6);
    //p.setPawnPos("R4", 23);

     cout<< p1.getPawnPos("R2")<< endl;
        
     list<Space> *ptr= p1.safePtr();
     list<Space>::iterator pos;
     
     for(pos=ptr->begin();pos!=ptr->end();++pos){
         cout<< pos->getClr()<< endl;
         cout<< pos->getPos()<< endl;
     }
    int x= p1.getPawnPos("R1");
    cout<<x<<endl;
    p1.inStart();
    //list<Space>::iterator pos= p.getSafeZone();
    


 
return 0;
}

