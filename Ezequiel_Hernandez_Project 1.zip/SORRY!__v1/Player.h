/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Player.h
 * Author: ezequ
 *
 * Created on April 27, 2021, 2:28 PM
 */
#include <map>
#include"Deck.h"
#include"Space.h"
#ifndef PLAYER_H
#define PLAYER_H

class Player{
private:
    std::map<int, char> pawns;// stores the position and the color of each layers pawns 
    std::set<Space> start; // game starts with the players start being full 
    std::set<Space> home;// the game is won when the player has moved all his pawns into home
    
public:
    Player(char, int);
    void setPawnPos(int);
    int getPawnPos();
    std::map<int,char> getPawns();// return the map of pawns.
    
};
//constructor sets the players color and how many pawns they start with 
Player::Player(char c, int p){
    
    for(int i=0;i< p;i++){   
    switch(c){
        case "R":  
            pawns.insert(std::make_pair(34,c));
        case "Y":  
            pawns.insert(std::make_pair(4,c));
        case "G":  
            pawns.insert(std::make_pair(19,c));
        case "B":  
            pawns.insert(std::make_pair(49,c));
    }
    }
    start=std::set<Space> (p,Space);
    home=std::set<Space> (p,Space);
}
void setPawnPos(int){
    
}
std::map<int,char> Player::getPawns(){
    return pawns;
}
#endif /* PLAYER_H */

