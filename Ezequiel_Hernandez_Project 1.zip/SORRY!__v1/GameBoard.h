/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Space.h
 * Author: ezequ
 *
 * Created on April 27, 2021, 12:33 PM
 */
#include<list>
#include"Space.h"

#ifndef GAMEBOARD_H
#define GAMEBOARD_H

class GameBoard{
private:
std::vector<char> boardSpaces; 
std::list<Space> track;
public:
    GameBaord();
    void slide();// 
    

    
};
#endif /* GAMEBOARD_H */

GameBoard::GameBaord(){
    
    for(int i= 0;i<60;i++){
        switch(i){
            case(i<=14):
             track.push_back(Space(i,"Y"));
            case(i<=29):
             track.push_back(Space(i,"G"));
            case(i<=44):
             track.push_back(Space(i,"R"));
            case(i<=60):
             track.push_back(Space(i,"B"));
        }
       
    }
} 
void GameBoard slide(){
    
    
    
}