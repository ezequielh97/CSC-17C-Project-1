/* 
 * File:   Deck.h
 * Author: Ezequiel Hernandez
 * Created on April 27, 2021, 3:58 PM
 */
#include<cstdlib>
#include <stack>
#ifndef DECK_H
#define DECK_H
class Deck{
private:
std::stack<std::pair<int, char>> cards;
void fillDeck(std::stack<std::pair<int, char>> &deck){
    int val;
    char effect;
    std::vector<std::pair<int, char>> temp;
    for(int i=0;i<=12;i++){
        for(int j=0;j<=3;j++){
            if(i!=6&&i!=9){
                val=i;
            if(i>=1 && i<= 5){
                effect='M';
            }else{
                switch(i) {
      case 0:
          effect='S';
         break;              
      case 7:
         effect='P';
         break;
      case 8 :
          effect='M';
          break;
      case 10 :
         effect='B';
         break;
      case 11 :
         effect='s';
         break;
      case 12 :
         effect='M';
         break;
      }
            } temp.push_back(std::make_pair(val, effect)); 
        }
    }
    }
    std::random_shuffle(temp.begin(),temp.end());
    for(int i=0;i<44;i++){
        deck.push(temp.back());
        temp.pop_back();
    }
}
public:
    Deck();
    std::pair<int,char> getDeck();
    std::pair<int,char> getCard();
#endif /* DECK_H */
};
Deck::Deck(){
    fillDeck();
}
std::stack<std::pair<int,char>> Deck::getDeck(){
    return cards;
}
std::pair<int,char> Deck::getCard(){
    std::pair<int,char> temp;
    temp = cards.top();
    cards.pop();
    return temp;
}
   
