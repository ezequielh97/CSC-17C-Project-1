/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Game.h
 * Author: ezequ
 *
 * Created on May 5, 2021, 4:26 AM
 */
#include <queue>
#include"GameBoard.h"
#include "Deck.h"
#include<string>
using namespace std;
#ifndef GAME_H
#define GAME_H
class Game{
private:
    Deck *deck;
    std::queue<std::string> turns;  //a queue of  "Yellow", "Red", "Green" and "Blue" to represent players and their turns
    GameBoard *board;
    int numP;     //number of players
    bool win;
    void move(int, char);    // takes user choice input, changes the position of the players pawns
    void split(char); // ask player how to split their move; calls move twice
    void sorry(char);     // send players pawn to their start area
    void playerTurns();
    void pawnSwitch(char);    //switches player pawn positions
    string inputValidation(char);
     std::pair<int,char> draw();
public:
   ~Game();
    Game(int);
    void start();    // start looping through the queue of players colors to 
 
};
Game::Game(int players){
    numP= players;
    deck= new Deck();
    board =new GameBoard(players);
    switch(players){
        case 4:
        turns.push("Blue");
        case 3:
        turns.push("Red");
        case 2:
            turns.push("Yellow");
            turns.push("Green");
            break;  
    };
}
Game::~Game(){}
void Game::start(){
    do{
 board->refresh();
 board->printBoard();
 playerTurns();
 win=board->fullHouse();       
    }while (win==false);
}
//Input: name of pawn being moved, value that pawned will be moved by
//Output:: moves the pawn
void Game::move(int move, char plrClr){
    string pawn;
    pawn= inputValidation( plrClr);
    board->setPawnPos(pawn, move);
    }
void Game::playerTurns(){
    pair<int,char> card;
    do{
       cout<< turns.front()<< " player's turn. "<<endl;
       printf("Press Enter to draw a card\n");
       cin.get();
       //cin.clear();
       card= draw();
       if(card.second=='M'){
       move(card.first,turns.front().at(0));
       }else if(card.second== 'S'){
           sorry(turns.front().at(0));
       }else if(card.second== 'W'){
           pawnSwitch(turns.front().at(0));
       }else if(card.second=='P'){
           split(turns.front().at(0));
       }
       turns.pop();
 board->refresh();
 board->printBoard();
    }
    while(turns.size()!=0);
 switch(numP){
        case 4:
        turns.push("Blue");
        case 3:
        turns.push("Red");
        case 2:
        turns.push("Yellow");
        turns.push("Green");
            break;  
    };
}
// player pawns chooses a pawn to target. targeted pawn is sent back to start by setPawnPos
void Game::sorry(char playerColor){
    string pawn;
    string target;
    int targetPosition;
    int pawnPosition;
    
    printf(" Input pawn your pawn you wish to switch.\n");
   pawn=inputValidation(playerColor);

    cout<< " Which pawn's place will yours take?"<< endl;
    cin>> target;
    targetPosition=board->pawns[target];
    pawnPosition= board->pawns[pawn];
    board->setPawnPos(pawn,targetPosition);
    board->setPawnPos(target, pawnPosition);
}
void Game::split(char playerColor){
    int move2;
    int move1;
    string pawn1;
    string pawn2;
    cout<< " Input the first pawn you wish to move"<< endl;
    pawn1=inputValidation(playerColor);
    cout << " How many space will it move? "<< endl;
    cin >> move1;
    while(move1>7){
        cout<< "You may not move more than 6 spaces"<< endl;
    }
    cout<< " Which other pawn would you like to move?"<< endl;
    pawn2=inputValidation(playerColor);
;
    
    board->setPawnPos(pawn1, move1);
    move2= 7-move1;
    board->setPawnPos(pawn2, move2); 
}
void Game::pawnSwitch(char playerColor){
    string pawn;
    string target;
    int temp;
    cout<< " Input your pawn you wish to switch."<< endl;
    pawn=inputValidation(playerColor);
    cout << " Which pawn's place will your pawn take? "<< endl;
    cin >> target;
    temp= board->pawns[target];
    board->pawns[target]=board->pawns[pawn];
    board->pawns[pawn]=temp;
}
pair<int,char> Game::draw(){
    std::pair<int,char> temp;
    temp =deck->getCard();
    int choice;
           switch(temp.second) {
      case 'S':
          std::cout<<" You drew a SORRY! card!!! You may: "<<endl;
          std::cout<<"1.)Move a pawn from your start area to take the place of another player's pawn, which must return to its own start area."<< endl;
          std::cout<<"2.)Move one of your pawns forward four spaces."<<endl;
          cin >> choice;
          if(choice==1){
              return temp;
          }else{
              temp.first=4;
              temp.second='M';
              return temp;
          }
         break;              
      case 'P':
           std::cout<<" You drew 7.You may: "<< endl;
           std::cout<<"1.)Move one of your pawns forward seven spaces"<< endl;
           std::cout<<"2.)Split the forward move between two of your pawns."<<endl;
           cin >> choice;
          if(choice==1){
              temp.first-=7;
              temp.second='M';
              return temp;
          }else{
              temp.first=7;
              temp.second='P';
              return temp;
          }
         break;
      case 'M':
        std::cout<< " You drew a move card. Move one of your pawns forward "<< temp.first<< " spaces."<< endl;
        return temp;
          break;
      case 'B' :
           std::cout<<" You drew 10. You may:"<< endl;
           std::cout<<"1.)Move one of your pawns forward ten spaces"<<endl;
           std::cout<<"2.)Move one of your pawns backward one space."<< endl;
           cin >> choice;
          if(choice==1){
              temp.first=10;
              temp.second='M';
              return temp;
          }else{
              temp.first=-1;
              temp.second='M';
              return temp;
          }
         break;
      case 's' :
          std::cout<<" You drew 11. You may"<< endl;
          std::cout<< "1.)Move one of your pawns forward 11 spaces"<< endl;
          std::cout<< "2.)Switch any one of your pawns with an opponent's."<< endl;
         cin >> choice;
          if(choice==1){
              temp.first=11;
              temp.second= 'M';
              return temp;
          }else{
              temp.first=0;
              temp.second='W';
              return temp;
          }
         break;
      }   
     return temp;      
}
string Game::inputValidation(char clr){
    string pawn;
    cin >> pawn;
    while(pawn.at(0)!=clr){
        cout<< " That's not one of your pawns, try again.(ex: Y2, B4, R1...)"<< endl;
        cin>> pawn;
    }
    return pawn;
}
#endif /* GAME_H */