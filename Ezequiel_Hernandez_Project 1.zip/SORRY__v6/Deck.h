/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Deck.h
 * Author: ezequ
 *
 * Created on May 1, 2021, 11:18 PM
 */
#include<string>
#include<algorithm>
#include<cstdlib>
#include <stack>
#ifndef DECK_H
#define DECK_H
using namespace std;
class Deck{
private:
std::stack<std::pair<int, char>> cards;
void fillDeck(){
    int val;
    char effect;
    std::vector<std::pair<int, char>> temp;
    for(int i=0;i<=12;i++){
        for(int j=0;j<=3;j++){
            if(i!=6&&i!=9){
                val=i;
            if(i>=1 && i<= 5){
                effect='M';
            }else{
                switch(i) {
      case 0:
          effect='S';
         break;              
      case 7:
         effect='P';
         break;
      case 8 :
          effect='M';
          break;
      case 10 :
         effect='B';
         break;
      case 11 :
         effect='s';
         break;
      case 12 :
         effect='M';
         break;
      }
            } temp.push_back(std::make_pair(val, effect)); 
       }
    }
  }
    std::random_shuffle(temp.begin(),temp.end());
    for(int i=0;i<44;i++){
        cards.push(temp.back());
        temp.pop_back();
    }
}
public:
    Deck();
    ~Deck();
    std::pair<int,char> getCard();
#endif /* DECK_H */
};
Deck::Deck(){
    fillDeck();
}
std::pair<int,char> Deck::getCard(){
        pair<int,char> t= cards.top();
        cards.pop();
        return t;
}