/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Player.h
 * Author: ezequ
 *
 * Created on April 30, 2021, 9:43 PM
 */
#include<set>
#include<string>
#include<map>
#include<list>
#include"Space.h"
#ifndef PLAYER_H
#define PLAYER_H

using namespace std;
class Player{
private:
    typedef map<string, int> PawnPositionMap;// stores the position and the color/key of each pawn 
    PawnPositionMap pawns;// the players pawns
      set<string>  home;// the spaces being full or empty will indicate how many pawns the player has there
      set<string> start;
      list<Space> safeZone;// player pawns cannot be targeted in a safeZone
public:
    Player(int);
    void setPawnPos(string,int);
    int getPawnPos(string);
    void homeRun(string);// inserts a key value in home
    void toStart(string);//inserts key to start, called when pawns are sent back
    void inStart();//outputs all keys currently in start
    list<Space> *safePtr();// return pointer to SafeZone
};
//constructor takes number 1-4. one number for each player 
Player::Player(int c){
string r= "R";
string y= "Y";
string g= "G";
string b= "B";
   for(int i=49;i<= 52;++i){   
    switch(c){
        case 1:  
            pawns.insert(make_pair(r+(char)i,-1));//-1 position indicates pawns are at start
            break;
        case 2:  
            pawns.insert(make_pair(y+(char)i,-1));//keys are set to Y1,Y2, 
            break;
        case 3:  
            pawns.insert(make_pair(g+(char)i,-1));
            break;
        case 4:  
            pawns.insert(make_pair(b+(char)i,-1));
            break;
    }
    }

PawnPositionMap::iterator pos;
for(pos=pawns.begin();pos!=pawns.end();++pos){// pawn keys are put in start
    start.insert(pos->first);
}
   pos=pawns.begin();
 for(int i=100;i<105;i++){                      //fills the safetyZone with spaces
        Space safety(i,pos->first.at(0));//
        safeZone.push_back(safety);
    }
}
void Player::setPawnPos(string key,int pos){
    start.erase(key);
    pawns[key]= pos;
}
int Player::getPawnPos(string key){
    return pawns[key];
}
void Player::homeRun(string key) {
    home.insert(key);
}
void Player::toStart(string key){
    pawns[key]=-1;
    start.insert(key);
}
void Player::inStart(){
    set<string>::iterator pos;
    cout <<"The pawns in start are: "; 
    for(pos=start.begin();pos!=start.end();++pos){
        cout<< *pos <<" "; 
    }
}
std::list<Space> *Player::safePtr(){
    list<Space> *ptr= &safeZone;
    return ptr;
}  
#endif /* PLAYER_H */

