/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Player.h
 * Author: ezequ
 *
 * Created on April 30, 2021, 9:43 PM
 */
#include<set>
#include<string>
#ifndef PLAYER_H
#define PLAYER_H

using namespace std;
class Player{
private:
      set<string>  home;// the spaces being full or empty will indicate how many pawns the player has there
      set<string> start;
      string color;
      //string choice;
public:
    Player();
    Player(int);
    void homeRun(string);// inserts a key value in home
    void toStart(string);// takes iterator and makes position of the pawn -1; adds that pawn's name to start
    void inStart();//outputs all keys currently in start 
};
//constructor takes number 1-4. one number for each player 
Player::Player(){

}
void Player::homeRun(string key) {
    home.insert(key);
    if(home.size()==4){
       printf("You win!!!!");
       printf("Ending Program.....");
      
    }
}
void Player::toStart(string key){
    start.insert(key);
    //[key]=-1;
}
void Player::inStart(){
    set<string>::iterator pos;
    cout <<"The pawns in start are: "; 
    for(pos=start.begin();pos!=start.end();++pos){
        cout<< *pos <<" "; 
    }
}
#endif /* PLAYER_H */

