/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Game.h
 * Author: ezequ
 *
 * Created on May 5, 2021, 4:26 AM
 */
#include <queue>
#include"GameBoard.h"
#include "Deck.h"
#include<string>

#ifndef GAME_H
#define GAME_H
class Game{
private:
    Deck *deck;
    std::queue<std::string> turns;  //a queue of  "Yellow", "Red", "Green" and "Blue" to represent players and their turns
    GameBoard *board;
    int numP;     //number of players
    
public:
   ~Game();
    Game(int);
    void startRound();    // start looping through the queue of players colors to 
    void move(string, int);    // takes user choice input, changes the position of the players pawns
    void split(); // ask player how to split their move; calls move twice
    void sorry();     // send players pawn to their start area
    void playerTurns();
    void pawnSwitch();    //switches player pawn positions
};
Game::Game(int plyrs){
    numP= plyrs;
    deck= new Deck();
    board =new GameBoard(plyrs);
    
    
    
}

Game::~Game(){
    
    
    
    
}

void Game::startRound(){
    
   
    
   

   
 board->refresh();
 board->printBoard();
    
 
 
}
//Input: name of pawn being moved, value that pawned will be moved by
//Output:: moves the pawn
void Game::move(string pwn,int pos){
    
    
    
    // check if players new position is take
    
    
        // if taken call sorry on the pawn in the targeted position
    
}
//Input: 
void Game::sorry(){
    
    
}

void Game::split(){
    
    
}
    

#endif /* GAME_H */