/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: ezequ
 *
 * Created on April 27, 2021, 10:13 PM
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <map>
#include"Player.h"
#include"GameBoard.h"


using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
   printf("\n");
    printf("\x1B[31mTexting\033[0m");//red text
    printf("\n");
    printf("\x1B[31mRed\033[0m");
    printf("\x1B[32mGreen\033[0m");
    printf("\x1B[33mYellow\033[0m");
    printf("\x1B[34mBlue\033[0m");
    printf("\n");
  
    GameBoard board;
    Player p1(1);
    Player p2(2);
    
    p2.inStart();
    cout<<p1.getPawnPos("R1")<< endl;
    p1.inStart();
    cout<<endl;
    cout<<"The board space color and number are:"<< endl;
  
    list<Space>::iterator pos;
    list<Space> *ptr= board.getTrackptr();
    for(pos=ptr->begin();pos!=ptr->end();++pos)
    {
        cout<<pos->getClr() << pos->getPos()<< endl;
    }
    board.printBoard();
return 0;
}

