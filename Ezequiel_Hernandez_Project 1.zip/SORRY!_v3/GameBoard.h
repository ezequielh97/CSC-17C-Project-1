/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* 
 * File:   GameBoard.h
 * Author: ezequ
 *
 * Created on May 1, 2021, 4:58 PM
 */
#include<list>
#include<tuple>
#include"Space.h"
#ifndef GAMEBOARD_H
#define GAMEBOARD_H

class GameBoard{
private:
std::list<Space> track;
std::list<Space> p1Safezone;
std::list<Space> p2Safezone;
std::list<Space> p3Safezone;
std::list<Space> p4Safezone;
std::string board[16][16]={
         {"═", "$ ", "═", "═", "═", "¤ ", "═", "═", "═", "═", "═", "═", "═", "═", "═", " ═"},
         {"║", "  ", "║ ", "≡", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " $"},
         {"║", "  ", "║ ", "  ", "  ", "  ", "  ", "  ", "  ", "Ø ", "═", "═", "═", "═", "═", " ║"},
         {"║", "  ", "║ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " ║"},
         {"║", "  ", "║ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "≡", " ║"},
         {"║", "  ", "║ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " ¤"},
         {"║", "  ", "Ø ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ║"},
         {"║", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ║"},
         {"║", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ║"},
         {"║", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " Ø", "  ", "  ║"},
         {"¤ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " ║ ", "  ", "║"},
         {"║", "≡", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " ║ ", "  ", "║"},
         {"║", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " ║ ", "  ", "║"},
         {"║", "═", "═", "═", "═", "═", "Ø ", "  ", "  ", "  ", "  ", "  ", "  ", " ║ ", "  ", "║"},
         {"$ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " ≡", "  ", "║ ", "  ", "║"},
         {" ═", "═", "═", "═", "═", "═", "═", "═", "═", "═", "¤ ", "═", "═", "═", " $ ", "═"},
    };// blank board game
        //each player has a safety zone that leads to home
      //Ø is home, pawns that land on $ slide forward 4 spaces to ¤
;
public:
    GameBoard();
    void printBoard();
    std::string getString(int,int);//returns the char of the element, if there is a pawn there it will only return its color letter
    std::list<Space> *getTrackptr();
    
    
};
#endif /* GAMEBOARD_H */

GameBoard::GameBoard(){
    
std::string r= "R";
std::string y= "Y";
std::string g= "G";
std::string b= "B";
    for(int i=0;i<=14;i++){// fills track with empty spaces
      track.push_back(Space(i,y));}
    for(int i=15;i<=29;i++){// fills track with empty spaces
      track.push_back(Space(i,g));}
    for(int i=30;i<=44;i++){// fills track with empty spaces
      track.push_back(Space(i,r));}
    for(int i=45;i<=59;i++){// fills track with empty spaces
      track.push_back(Space(i,b));}
    
    for(int i=100;i<=104;i++){// fills Safe zone with empty spaces
      p1Safezone.push_back(Space(i,y));}
    for(int i=105;i<=109;i++){// fills Safe zone with empty spaces
       p2Safezone.push_back(Space(i,g));}
    for(int i=110;i<=114;i++){// fills Safe zone  with empty spaces
       p3Safezone.push_back(Space(i,r));}
    for(int i=115;i<=119;i++){// fills Safe zone with empty spaces
       p4Safezone.push_back(Space(i,b));}

} 

void GameBoard::printBoard(){
    for(int i=0;i<16;i++){
        for(int j=0;j<16;j++){
                std::cout<< board[i][j];
        }
        std::cout<<std::endl;
    }  
}
std::list<Space> *GameBoard::getTrackptr(){
    std::list<Space> *ptr=&track;
    return ptr;
}
std::string GameBoard::getString(int i, int j){
    
    return board[i][j];
}