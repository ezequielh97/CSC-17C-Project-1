/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Space.h
 * Author: ezequ
 *
 * Created on May 2, 2021, 12:57 PM
 */
#ifndef SPACE_H
#define SPACE_H
class Space{
private:
  int position;
  bool empty;
  std::string spaceColor;
public:

    Space(int, std::string);
    bool isEmpty();// returns true if space is empty
    void makeEmpty();// 
    int getPos();//returns board position 
    std::string getClr();// returns the color of the space
};
#endif /* SPACE_H */

Space::Space(int n, std::string clr){
    position=n;
    spaceColor= clr;
    empty = true;
}
bool Space::isEmpty(){
    return empty;
}
void Space::makeEmpty(){
    empty= true;
}
int Space::getPos(){
    return position;
}
std::string Space::getClr(){
    return spaceColor;
}