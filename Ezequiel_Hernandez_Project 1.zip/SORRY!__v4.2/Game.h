/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Game.h
 * Author: ezequ
 *
 * Created on April 30, 2021, 1:49 PM
 */

#include <queue>
#include"GameBoard.h"
#include"Deck.h"

#ifndef GAME_H
#define GAME_H
class Game{
private:
    std::queue<Player> turns;// game will loop thought queue t keep track of the turns
    Deck deck;
    GameBoard *board;
    int numP;///number of players
    bool win;
    
public:
    Game(int);
    void start();//initialize the players
    bool end();//checks if any players have their home full at the end of their turn
    void move();// takes user choice input, changes the position of the players pawns
    void split();
    void sorry();// send players pawn to their start area
    void switchPawns();
    void playerTurns();
    void pawnSwitch();//switches player pawn positions
};
Game::Game(int plyrs){
    numP= plyrs;
  
    board =new GameBoard(plyrs);
    
    
    
}



void Game::start(){
    queue<Player> nxtRnd;
    
    
    //pair<int,char> temp= draw;
    
}
//void Game::move(int val, string pwn, Player &player){//take in players choice, and the reference to that players
    
    // check if players new position is take
    // if taken call sorry on the pawn in the targeted position
    
    
    

#endif /* GAME_H */