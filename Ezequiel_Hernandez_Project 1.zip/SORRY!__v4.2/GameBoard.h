/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* 
 * File:   GameBoard.h
 * Author: ezequ
 *
 * Created on May 1, 2021, 4:58 PM
 */
#include<map>
#include<list>
#include<tuple>
#include <vector>
#include <set>
#include<iterator>
#include"Space.h"
#ifndef GAMEBOARD_H
#define GAMEBOARD_H
using namespace std;


class GameBoard{
private:

std::list<Space> track;
std::list<Space> p1Safezone;
std::list<Space> p2Safezone;
std::list<Space> p3Safezone;
std::list<Space> p4Safezone;
std::set<string> p1start;
std::set<string> p1home;
std::set<string> p2start;
std::set<string> p2home;
std::set<string> p3start;
std::set<string> p3home;
std::set<string> p4start;
std::set<string> p4home;
std::string board[16][16]={
         {"Y", "$ ", "Y", "Y", "Y", "¤ ", "Y", "Y", "Y", "Y", "Y", "Y", "Y", "Y", "Y", " Y"},
         {"B", "  ", "║ ", "≡", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " $"},
         {"B", "  ", "║ ", "  ", "  ", "  ", "  ", "  ", "  ", "Ø ", "═", "═", "═", "═", "═", " G"},
         {"B", "  ", "║ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " G"},
         {"B", "  ", "║ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "≡", " G"},
         {"B", "  ", "║ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " ¤"},
         {"B", "  ", "Ø ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  G"},
         {"B", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  G"},
         {"B", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  G"},
         {"B", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " Ø", "  ", "  G"},
         {"¤ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " ║ ", "  ", "G"},
         {"B", "≡", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " ║ ", "  ", "G"},
         {"B", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " ║ ", "  ", "G"},
         {"B", "═", "═", "═", "═", "═", "Ø ", "  ", "  ", "  ", "  ", "  ", "  ", " ║ ", "  ", "G"},
         {"$ ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  ", " ≡", "  ", "║ ", "  ", "G"},
         {" R", "R", "R", "R", "R", "R", "R", "R", "R", "R", "¤ ", "R", "R", "R", " $ ", "R"},
    };// blank board game
        //each player has a safety zone that leads to home
      //Ø is home, pawns that land on $ slide forward 4 spaces to ¤
;
public:
    friend class Space;
   typedef map<string, int> pawnMap;// stores the position and the color/key of each pawn the players pawns
   pawnMap pawns; 
   GameBoard();
   GameBoard(int);
    void setPawnPos(string,int);
    int getPawnPos(string);
    void printBoard();
    std::string getString(int,int);//returns the char of the element, if there is a pawn there it will only return its color letter
    std::list<Space> *getTrackptr();
    void refresh();// iterates through track, if position is occupied by pawns, sets Space.isEmpty to false
    string getName(int);// returns the pawns name    
    void homeRun(string, set<Space> &);// inserts a key value in home
    void toStart(string, set<Space> &);// takes iterator and makes position of the pawn -1; adds that pawn's name to start
    void inStart();//outputs all keys currently in start 
    
};
#endif /* GAMEBOARD_H */

GameBoard::GameBoard(int numPlayers){
std::string r= "R";
std::string y= "Y";
std::string g= "G";
std::string b= "B";
    for(int i=0;i<=14;i++){// fills Yellow track with empty spaces
      track.push_back(Space(i,y));}
    for(int i=15;i<=29;i++){// fills Green track with empty spaces
      track.push_back(Space(i,g));}
    for(int i=30;i<=44;i++){// fills Red track with empty spaces
      track.push_back(Space(i,r));}
    for(int i=45;i<=59;i++){// fills Blue track with empty spaces
      track.push_back(Space(i,b));}
    
    for(int i=100;i<=104;i++){// fills  Yellow Safe zone with empty spaces
      p1Safezone.push_back(Space(i,y));}
    for(int i=105;i<=109;i++){// fills Green Safe zone with empty spaces
       p2Safezone.push_back(Space(i,g));}
    for(int i=110;i<=114;i++){// fills Red Safe zone  with empty spaces
       p3Safezone.push_back(Space(i,r));}
    for(int i=115;i<=119;i++){// fills Blue Safe zone with empty spaces
       p4Safezone.push_back(Space(i,b));}



for(int i=49;i<= 52;++i){   
    switch(numPlayers){
        case 1:  
            pawns.insert(make_pair(y+(char)i,-1));//-1 position indicates pawns are at start
            break;
        case 2:  
            pawns.insert(make_pair(g+(char)i,-1));//keys are set to Y1,Y2, 
            break;
        case 3:  
            pawns.insert(make_pair(r+(char)i,-1));
            break;
        case 4:  
            pawns.insert(make_pair(b+(char)i,-1));
            break;
    }
    }

} 
void GameBoard::printBoard(){
    for(int i=0;i<16;i++){
        for(int j=0;j<16;j++){
                std::cout<< board[i][j];
        }
        std::cout<<std::endl;
    }  
}
std::list<Space> *GameBoard::getTrackptr(){
    std::list<Space> *ptr=&track;
    return ptr;
}
std::string GameBoard::getString(int i, int j){
    
    return board[i][j];
}
string GameBoard::getName(int pos){
    
  pawnMap::iterator pwns;
    for(pwns=pawns.begin();pwns!=pawns.end();++pwns){
        if(pwns->second==pos){
            return pwns->first;
        } 
    }
  return "return";
    
}
void GameBoard:: refresh(){
    std::set<int> taken;// holds the cuurently occupied spaces
    std::list<Space>::iterator space;
    pawnMap::iterator pwns;
    for(pwns=pawns.begin();pwns!=pawns.end();++pwns){  // inserts occupied positions into a set
        taken.insert(pwns->second); 
    }
    
    for(space=track.begin();space!=track.end();++space){// if a position is full that Space is set to be not empty
        if (taken.find(space->getPos() ) != taken.end() ){
            space->notEmpty();
        }
    }
    
    for(space=track.begin();space!=track.end();++space){//changes the string in Board if corresponding space is full 
        
        if(space->isEmpty()!=true){
            
            if(space->getPos()>=0&&space->getPos()<=14){
                board [0][space->getPos()]= getName(space->getPos());
            }
            else if(space->getPos()>=15&&space->getPos()<=29){
                for(int i=1;i<=15;i++){
                board[15][i]= getName(space->getPos());
                }
            }
            else if(space->getPos()>=30&&space->getPos()<=44){
             for(int i=1;i<=15;i++){
                board[i][15]= getName(space->getPos());
                }
            }
             else if(space->getPos()>=45&&space->getPos()<=59){
             for(int i=1;i<=15;i++){
                board[i][0]= getName(space->getPos());
                }
                
            }
    }else if(space->isEmpty()==true){// output for unoccupied spaces
        
        if(space->getPos()>=0 && space->getPos()<=14){
            if(space->getPos()==1||space->getPos()==9){
                board[0][space->getPos()]="$";
            }else if(space->getPos()==4||space->getPos()==13){
                board[0][space->getPos()]="¤";
            }else 
                board [0][space->getPos()]= "Y";
            }
        else if(space->getPos()>= 15 && space->getPos()<=29){
            if(space->getPos()==16||space->getPos()==24){
                board[0][space->getPos()]="$";
            }else if(space->getPos()==19||space->getPos()==28){
                board[0][space->getPos()]="¤";
            }else 
                board [0][space->getPos()]= "G";  
            }
        else if(space->getPos() >=31&&space->getPos()<=45){
               if(space->getPos()==31||space->getPos()==39){
                board[0][space->getPos()]="$";
            }else if(space->getPos()==34||space->getPos()==43){
                board[0][space->getPos()]="¤";
            }else 
                board [0][space->getPos()]= "G";
            }
        else if(space->getPos() >=46&&space->getPos()<=59){
                 if(space->getPos()==44||space->getPos()==54){
                         board[0][space->getPos()]="$";
                     }else if(space->getPos()==49||space->getPos()==58){
                        board[0][space->getPos()]="¤";
                        }else 
                            board [0][space->getPos()]= "G";
             }
    
    
        }
    }
    // same process but now for safeZones
    list<Space> safeZones;
    safeZones.merge(p1Safezone);
    safeZones.merge(p2Safezone);
    safeZones.merge(p3Safezone);
    safeZones.merge(p4Safezone);
    taken.clear();
    
    for(pwns=safeZones.begin();pwns!=safeZones.end();++pwns){  // inserts occupied positions into a set
        taken.insert(pwns->second); 
    }
    
    for(space=safeZones.begin();space!=safeZones.end();++space){// if a position is full that Space is set to be not empty
        if (taken.find(space->getPos() ) != taken.end() ){
            space->notEmpty();
        }
        
        for(space=p1Safezone.begin();space!=p1Safezone.end();++){//yellow SafeZone
            
            if(space->isEmpty()==true){
                board[2][space->getPos()-99]= "║";
               
            }else if(space->isEmpty()!= true){
                
                board[2][space->getPos()-99]= getName(space->getPos());
            }

        }
        for(space=p2Safezone.begin();space!=p2Safezone.end();++){//green SafeZone
            
            if(space->isEmpty()==true){
                board[space->getPos()-105][2]= "═";
                
            }else if(space->isEmpty()!= true){
                
                board[space->getPos()-105][2]= getName(space->getPos());
                
            }
            
        }for(space=p3Safezone.begin();space!=p3Safezone.end();++){//red SafeZone
            
            if(space->isEmpty()==true){
                 board[13][space->getPos()-100]= "║";
                
            }else if(space->isEmpty()!= true){
                board[13][space->getPos()-100]= getName(space->getPos());

            }
            
        }for(space=p4Safezone.begin();space!=p4Safezone.end();++){//blue SafeZone
            
            if(space->isEmpty()==true){
                board[space->getPos()-114][13]= "═";

            }else if(space->isEmpty()!= true){
                board[space->getPos()-114][13]= getName(space->getPos());

            }
            
        }
        
        
    }  
}


void Player::homeRun(string key, set<Space> &home) {
    home.insert(key);
    if(home.size()==4){
       printf("You win!!!!");
       printf("Ending Program.....");
      
    }
}
void Player::toStart(string key, set<Space> &start){
    start.insert(key);
    //[key]=-1;
}
void Player::inStart(){
    set<string>::iterator pos;
    cout <<"The pawns in start are: "; 
    for(pos=start.begin();pos!=start.end();++pos){
        cout<< *pos <<" "; 
    }
}