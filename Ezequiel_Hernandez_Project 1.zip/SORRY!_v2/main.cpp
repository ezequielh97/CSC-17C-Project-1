/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: ezequ
 *
 * Created on April 27, 2021, 12:32 PM
 */

#include <cstdlib>

using namespace std;

#include"Player.h"
//#include"GameBoard.h"

int main(int argc, char** argv) {

    Player p1(1);
    Player p1(2);
    Player p3(3);
    
    list<Space> *ptr= p1.safePtr();
    list<Space>::iterator pos;
    
    for(pos=ptr->begin();pos!=ptr->end();++ptr){
        
        cout<<pos->getClr()<<endl;
        cout<< pos->getClr()<<end;
    
    }
    
    
    
    return 0;
}

