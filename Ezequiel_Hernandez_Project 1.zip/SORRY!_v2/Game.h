/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Game.h
 * Author: ezequ
 *
 * Created on April 30, 2021, 1:49 PM
 */

#include <queue>

#include"Player.h"
#include"GameBoard.h"
#include"Deck.h"

#ifndef GAME_H
#define GAME_H
class Game{
private:
    std::queue<Player> turns;// game will loop thought queue t keep track of the turns
    std::stack<std::pair<int, char>> deck;
    GameBoard board;
    int numPlayers;///number of players
    bool win;
    
public:
    Game();
    void start(int);//initialize the players
    bool end();//checks if any players have their home full at the end of their turn
    
    
};
Game::Game(int numPlayers){
    for(int i=1;i<=numPlayers;i++){
        turns.push(Player(i));
        
    }
    
}
Game::start(int ){
    if(players >=2||players<= 4){
         numPlayers= players;  
    }
    for(int i=1;i<=players;i++){
        Player
        
    }
}
#endif /* GAME_H */

