/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Player.h
 * Author: ezequ
 *
 * Created on April 27, 2021, 2:28 PM
 */
#include <map>
#include"Space.h"
#include<string>
#include <set>
#include <list>
#ifndef PLAYER_H
#define PLAYER_H

class Player{
private:
    typedef std::map<std::string, int> PawnPositionMap;// stores the position and the color/key of each pawn 
    PawnPositionMap pawns;// the players pawns
    std::set<std::string> start;// the spaces being full or empty will indicate how many pawns the player has there
    std::set<std::string> home;// the spaces being full or empty will indicate how many pawns the player has there
    std::list<Space> safeZone;// player pawns cannot be targeted in a safeZone
    
public:
    Player();
    Player(int);
    void setPawnPos(std::string, int);
    int getPawnPos(std::string);
    void homeRun(std::string);// inserts a key value in home
    void goToStart(std::string);//inserts key to start, called when pawns are sent back
    void inStart();//outputs all keys currently in start
    std::list<Space> *safePtr();// return pointer to SafeZone};
};
#endif /* PLAYER_H */
    
Player::Player(){}
//constructor takes number 1-4. one number for each player 
Player::Player(int c){
std::string r= "R";
std::string y= "Y";
std::string g= "G";
std::string b= "B";
   for(int i=49;i<= 52;++i){   
    switch(c){
        case 1:  
            pawns.insert(make_pair(r+(char)i,-1));//-1 position indicates pawns are at start
            break;
        case 2:  
            pawns.insert(make_pair(y+(char)i,-1));//keys are set to Y1,Y2, 
            break;
        case 3:  
            pawns.insert(make_pair(g+(char)i,-1));
            break;
        case 4:  
            pawns.insert(make_pair(b+(char)i,-1));
            break;
    }
    }

PawnPositionMap::iterator pos;
for(pos=pawns.begin();pos!=pawns.end();++pos){// pawn keys are put in start
    start.insert(pos->first);
    
    } 
      pos=pawns.begin();
 for(int i=100;i<105;i++){                      //fills the safetyZone with spaces  
        Space safety(i,pos->first.at(0) );      //safeZones have position numbers 100-104
        safeZone.push_back(safety);
    }
 
}
void Player::setPawnPos(std::string key,int pos){
    pawns[key]= pos;
}
int Player::getPawnPos(std::string pwn){
    return pawns[pwn];
}
void Player::homeRun(std::string key) {
    home.insert(key);
}
void Player::goToStart(std::string key){
    pawns[key]=-1;
    start.insert(key);
}
void Player::inStart(){
    std::set<std::string>::iterator pos;
    std::cout <<"The keys in start are: "; 
    for(pos=start.begin();pos!=start.end();++pos){
        cout<< *pos <<" "; 
    }
}
std::list<Space> *Player::safePtr(){
    std::list<Space> *ptr= &safeZone;
    return ptr;
}  